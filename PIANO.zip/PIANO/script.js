
//baixar 5 sons
function show1(){
    var snd = new Audio("./sonido1.mp3");
    snd.play();
}

function show2(){
    var snd = new Audio("./sonido2.mp3");
    snd.play();
}

function show3(){
    var snd = new Audio("./sonido3.mp3");
    snd.play();
}

function show4(){
    var snd = new Audio("./sonido4.mp3");
    snd.play();
}

function show5(){
    var snd = new Audio("./sonido5.mp3");
    snd.play();
}

function show6(){
    var snd = new Audio("./sonidocuerda");
    snd.play();
}
function canço1(){
    var snd = new Audio("./Eyeofthetiger.mp3");
    snd.play();
}
function canço2(){
    var snd = new Audio("./finalcountdown.mp3");
    snd.play();
}
function canço3(){
    var snd = new Audio("./Eyeofthetiger.mp3");
    snd.play();
}
let configTeclat = {prevent_repeat : true};
let eventTeclat = new window.keypress.Listener(this,configTeclat);

eventTeclat.simple_combo('a',show1);
eventTeclat.simple_combo('s',show2);
eventTeclat.simple_combo('d',show3);
eventTeclat.simple_combo('f',show4);
eventTeclat.simple_combo('g',show5);
eventTeclat.simple_combo('h',show6);
eventTeclat.sequence_combo('e o t t',canço1);
eventTeclat.sequence_combo('t f c',canço2);
eventTeclat.sequence_combo('b l v',canço3);


//fer 3 bases de cançons llargues amb 5 mini audios i fer cançons. 3 cançons amb sequence combo